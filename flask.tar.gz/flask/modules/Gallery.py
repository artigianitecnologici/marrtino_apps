import os
from definition import *
from flask import Response # Changed line
import io
import zipfile
import time

class Gallery:

    def __init__(self):
        pass

    '''
    * Read folder names inside photo folder
    * @param
    *   NONE
    *
    * @return
    *   $final (ARRAY)
    '''
    def get_all_gallery(self):
        galleries = [name for name in os.listdir(Gallery_Folder)]
        return galleries

    '''
    * Create folder using the name argument
    * @param
    *   $name (string)
    *
    * @return
    *   Boolean
    '''
    def add_gallery(self,gallery_name):
        if os.path.isdir(Gallery_Folder+gallery_name) is False:
            if os.mkdir(Gallery_Folder+gallery_name):
                return True
        else:
            return False


    '''
    * Download folder using the name argument
    * @param
    *   $name (string)
    *
    * @return
    *   Boolean
    '''
    def download_gallery(self, gallery_name):
        if os.path.isdir(Gallery_Folder+gallery_name) is True:
           os.DirEntry
           # if os.removedirs(Gallery_Folder+gallery_name):
           #     return True
           # else:
           #     return False
       
        FILEPATH = r"photo.zip"
        fileobj = io.BytesIO()
        with zipfile.ZipFile(fileobj, 'w') as zip_file:
            zip_info = zipfile.ZipInfo(FILEPATH)
            zip_info.date_time = time.localtime(time.time())[:6]
            zip_info.compress_type = zipfile.ZIP_DEFLATED
            with open(FILEPATH, 'rb') as fd:
                zip_file.writestr(zip_info, fd.read())
        fileobj.seek(0)

        # Changed line below
        return Response(fileobj.getvalue(),
                        mimetype='application/zip',
                        headers={'Content-Disposition': 'attachment;filename=photo.zip'})



    '''
    * Delete folder using the name argument
    * @param
    *   $name (string)
    *
    * @return
    *   Boolean
    '''
    def delete_gallery(self, gallery_name):
        if os.path.isdir(Gallery_Folder+gallery_name) is True:
            if os.removedirs(Gallery_Folder+gallery_name):
                return True
            else:
                return False
        else:
            return False

    '''
    * rename a gallery folder name
    * @param
    *   $currentName (string)
    *   $newName (string)
    *
    * @return
    *   Boolean
    '''
    def edit_gallery_name(self,oldName,newName):
        if os.path.isdir(Gallery_Folder+oldName) is True:
            if os.rename(Gallery_Folder+oldName, Gallery_Folder+newName):
                return True
        else:
            return False

