. .venv/bin/activate
python3 app.py 
